<?php 

define("LOGIN","login");

define("CMS","cms");

define("DIR","directors");

$admin_paging_value=20; 
$front_page_value=10;

?>