<div class="chromestyle" id="chromemenu">



<ul>



<li><a href="admin.php" >Site Controller</a></li>

<li><a href="add_news.php" rel="dropmenu1">Add News</a></li>

<li><a href="logout.php">Logout</a></li>



</ul>



</div>




<div id="dropmenu1" class="dropmenudiv">

<a href="add_news.php">Add News</a>

<a href="view_news.php">View/Edit News</a>

</div>







<script type="text/javascript">



cssdropdown.startchrome("chromemenu")



</script>