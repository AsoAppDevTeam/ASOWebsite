<?php 

include("../include/dbconnect.php");

include("../include/constants.php");

include("fckeditor/fckeditor.php");



if($_SESSION['admin_id']=="")

header("Location:index.php");



if(isset($_POST['pic']))

{

 						

$dir = rand(1,100000);

$img = $_FILES["file"]["name"];

$imgdir = $dir.$img;	

$imgdir1 = "images/".$dir.$img;		

		

		 move_uploaded_file($_FILES["file"]["tmp_name"],

		"images/".$imgdir);



$name = $_POST['name'];

$qual = $_POST['qual'];

$desc = $_POST['desc'];



		$InsQuery="INSERT INTO ".DIR." (`name`, `qualification`, `description`, `pic_url`) VALUES ('$name', '$qual', '$desc', '$imgdir1')";

		$ExQuery=mysql_query($InsQuery);

		header("Location:view_dir.php?flag=addsuc");

	

}







?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html><head>

<title><?php echo $admintitle;?></title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="adminstyle/style.css" rel="stylesheet" type="text/css" media="all">

<link rel="stylesheet" type="text/css" href="chrometheme/chromestyle.css" />

<script type="text/javascript" src="adminscripts/chrome.js"></script>

<script type="text/javascript" src="../fckeditor/fckeditor.js"></script> 

<script type="text/javascript" src="chromejs/chrome.js">



/***********************************************

* Chrome CSS Drop Down Menu- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)

* This notice MUST stay intact for legal use

* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code

***********************************************/



</script>

<script language="javascript" type="text/javascript">

function subscriber_validation(){

	var direc = document.adddirec.name.value;

	var qual = document.adddirec.qual.value;

	var desc = document.adddirec.desc.value;

    var file = document.adddirec.file.value;



   if(direc == '') {

    alert('Please Enter the Director Name');

    return false;

	}

   else if(qual == '') {

    alert('Please Enter the director Qualification');

    return false;

	}

   else if(desc == '') {

    alert('Please Enter the director Description');

    return false;

	}

   else if(file == '') {

    alert('Please Upload File');

    return false;

	}

   

}



</script>



<style type="text/css">

<!--

.style1 {

	color: #FF0000;

	font-weight: bold;

	font-size:10px;

}

-->

</style>

</head>



<body  onLoad="set_interval()" onmousemove="reset_interval()" onclick="reset_interval()" onkeypress="reset_interval()" onscroll="reset_interval()">

<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0">

  <tr>

    <td><?php include("../include/admintop.php");?></td>

  </tr>

    <tr>

    <td><?php include("../include/adminmenu.php");?></td>

  </tr>

  <tr>

    <td><p>&nbsp;</p>

      <p>&nbsp;</p>

       

     <form action="" method="post" name="adddirec" id="adddirec"  enctype="multipart/form-data" onSubmit="return subscriber_validation();">

       <p>&nbsp;</p>

        <table width="70%"  border="0" align="center" cellpadding="4" cellspacing="0"  class="adminhead">

          <tr bgcolor="#D8251D"> 

            <td height="26" colspan="2" class="adminheadtext">Add Director's Details</td>

          </tr>

          <tr> 

            <td colspan="2" align="center" class="error">&nbsp;</td>

          </tr>

          <tr>

            <td align="right" class="content"> Name</td>

            <td align="left" class="content"><input name="name" type="text" id="name"></td>

          </tr>

          <tr> 

            <td align="right" class="content">Qualification</td>

            <td align="left" class="content"><input name="qual" type="text" id="qual"></td>

          </tr>

          <tr> 

            <td align="right" class="content">Description</td>

            <td align="left" class="content"><textarea name="desc" cols="35" rows="3" id="desc"></textarea></td>

          </tr>

          <tr> 

            <td colspan="2" class="content"><table width="87%" border="0" align="center" cellpadding="2" cellspacing="2" id="tabUploadcoms" >

                <tr> 

                  <td width="38%" align="right" class="Content1">Image</td>

                  <td width="60%" align="left" class="text"><input name="file" type="file" id="file" style="FONT: 11px Verdana, Arial, Helvetica, sans-seri; text-decoration:none; color: #006699;" /></td>

                </tr>

                <tbody>

                </tbody>

              </table></td>

          </tr>

          <tr> 

            <td width="41%" align="right" class="content">&nbsp;</td>

            <td width="59%" align="left" class="content">&nbsp;</td>

          </tr>

          <tr> 

            <td colspan="2" align="center" class="content"><input name="pic" type="submit" class="pic" id="pic" value="Submit"> 

            </td>

          </tr>

        </table>

      </form>

      <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>    <p>&nbsp;</p>

    <p>&nbsp;</p></td>

  </tr>

  <tr>

    <td><?php include("../include/adminbottom.php");?></td>

  </tr>

</table>

</body>

</html>