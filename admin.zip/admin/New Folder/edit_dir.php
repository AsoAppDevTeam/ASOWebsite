<?php 

include("../include/dbconnect.php");

include("../include/constants.php");

include("fckeditor/fckeditor.php");



if($_SESSION['admin_id']=="")

header("Location:index.php");





$id=$_REQUEST['id'];

if(isset($_POST['update_img'])){

$name=$_POST['name'];

$qual = $_POST['qual'];

$desc = $_POST['desc'];



if (($_FILES["file"]["type"] == "image/gif")

|| ($_FILES["file"]["type"] == "image/jpeg")

|| ($_FILES["file"]["type"] == "image/pjpeg")

|| ($_FILES["file"]["type"] == "image/png"))

{

  if ($_FILES["file"]["error"] > 0)

    {

    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";

	}

}







$dir = rand(1,100000);

$img = $_FILES["file"]["name"];

$imgdir = $dir.$img;	

$imgdir1 = "images/".$dir.$img;		

		

		 move_uploaded_file($_FILES["file"]["tmp_name"],

		"images/".$imgdir);





$InsQuery="UPDATE ".DIR." SET  `name`='$name', `qualification`='$qual', `description`='$desc', `pic_url`='$imgdir1' where id='$id'";

		$ExQuery=mysql_query($InsQuery);

		

		header("Location:view_dir.php?flag=editsuc");

	

}

$SelQuery_Zone="SELECT * FROM ".DIR." where id='$id'";

$q1=mysql_query($SelQuery_Zone);

echo mysql_error();

$nt1=mysql_fetch_array($q1);

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>

<title><?php echo $admintitle;?></title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="adminstyle/style.css" rel="stylesheet" type="text/css" media="all">

<link rel="stylesheet" type="text/css" href="chrometheme/chromestyle.css" />

<script type="text/javascript" src="adminscripts/chrome.js"></script>

<script type="text/javascript" src="../fckeditor/fckeditor.js"></script> 

<script type="text/javascript" src="chromejs/chrome.js">



/***********************************************

* Chrome CSS Drop Down Menu- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)

* This notice MUST stay intact for legal use

* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code

***********************************************/



</script>

<script language="javascript" type="text/javascript">

function subscriber_validation(){



	var name = document.editdirec.name.value;

	var qual = document.editdirec.qual.value;

	var desc = document.editdirec.desc.value;

	var file = document.editdirec.file.value;

	

	if(name == '') {

    alert('Please Enter the Director Name');

    return false;

	}

	else if(qual == '') {

    alert('Please Enter the Director Qualification');

    return false;

	}

	else if(desc == '') {

    alert('Please Enter director Description');

    return false;

	}

	else if(file == '') {

    alert('Please Upload File');

    return false;

	}	

}



</script>



<style type="text/css">

<!--

.style1 {

	color: #FF0000;

	font-weight: bold;

	font-size:10px;

}

-->

</style>

</head>



<body  onLoad="set_interval()" onmousemove="reset_interval()" onclick="reset_interval()" onkeypress="reset_interval()" onscroll="reset_interval()">

<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0">

  <tr>

    <td><?php include("../include/admintop.php");?></td>

  </tr>

    <tr>

    <td><?php include("../include/adminmenu.php");?></td>

  </tr>

  <tr>

    <td align="left"><p>&nbsp;</p>

      <p>&nbsp;</p>

       

      <form action="edit_dir.php" method="post" name="editdirec" id="editdirec"  enctype="multipart/form-data" onSubmit="return subscriber_validation();">

        <p>&nbsp;</p>

        <table width="70%"  border="0" align="center" cellpadding="4" cellspacing="0"  class="adminhead">

          <tr bgcolor="#D8251D"> 

            <td colspan="2" class="adminheadtext">Edit Director's Details</td>

          </tr>

          <?php if($flag != "") { ?>

          <tr> 

            <td colspan="2" align="center" class="error"><?php echo $flag;?></td>

          </tr>

          <?php } ?>

          <tr> 

            <td align="right" class="content"> Name</td>

            <td align="left" class="content"><input name="name" type="text" id="name" value="<?php echo $nt1['name']; ?>"></td>

          </tr>

          <tr>

            <td align="right" class="content">Qualification</td>

            <td align="left" class="content"><input name="qual" type="text" id="qual" value="<?php echo $nt1['qualification']; ?>"></td>

          </tr>

          <tr> 

            <td align="right" class="content">Description</td>

            <td align="left" class="content"><textarea name="desc" cols="35" rows="3" id="desc"><?php echo $nt1['description']; ?></textarea></td>

          </tr>

          <tr> 

            <td align="right" class="content">Image</td>

            <td align="left" class="content"><input name="file" type="file" id="file" style="FONT: 11px Verdana, Arial, Helvetica, sans-seri; text-decoration:none; color: #006699;" /></td>

          </tr>

          <tr> 

            <td align="right" class="content">Preview</td>

            <td align="left" class="content"><img src="<?php echo $nt1['pic_url'];?>" width="60" height="60" /></td>

          </tr>

          <tr> 

            <td width="41%" align="right" class="content">&nbsp;</td>

            <td width="59%" align="left" class="content">&nbsp;</td>

          </tr>

          <tr> 

            <td colspan="2" align="center" class="content"><input name="update_img" type="submit" class="submitbutton" id="update_img" value="Update"> 

              <input name="id" type="hidden" id="id" value="<?php echo $id;?>"></td>

          </tr>

        </table>

      </form> 

      <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>    <p>&nbsp;</p>

    <p>&nbsp;</p></td>

  </tr>

  <tr>

    <td><?php include("../include/adminbottom.php");?></td>

  </tr>

</table>

</body>

</html>