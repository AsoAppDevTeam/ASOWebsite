<style type="text/css">

<!--

.adminpanel {

	color:#FF0000;

	font-weight: bold;

	font-family: Arial, Helvetica, sans-serif;

	font-size:60px;

}

.style4 {

	font-size: xx-large;

	color: #eca33c;

	font-family: Georgia, "Times New Roman", Times, serif;

	font-weight: bold;

	font-style: italic;

}

.style5 {

	font-size:x-large;

	color: #D8251D;

	font-family: Georgia, "Times New Roman", Times, serif;

	font-weight: bold;

	font-style: italic;

}

-->

</style>

<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">

      <tr>

        <td width="40%" height="103" align="left" valign="middle" class="style5" >ASO Savings &amp; Loans</td>

        <td width="60%" align="left" valign="middle" ><span class="style4">Control Panel </span></td>

      </tr>

      <tr>

        <td align="left" valign="top"  colspan="2"  bgcolor="#D8251D" height="8"></td>

      </tr>

</table>

