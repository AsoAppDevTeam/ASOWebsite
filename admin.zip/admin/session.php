<?php echo $_SESSION['admin_id'];
?>